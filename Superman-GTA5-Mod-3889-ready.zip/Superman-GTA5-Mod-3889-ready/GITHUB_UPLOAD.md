# Загрузка в GitHub

1. Открой репозиторий `Superman-GTA5-Mod-3889`.
2. Загрузить можно содержимое этого ZIP в корень репозитория.
3. ВАЖНО: не создавай `include/ScriptHookV/include/ScriptHookV`.
   Должно быть ровно:

   include/ScriptHookV/main.h

4. `main.h` берётся из официального ScriptHookV SDK.
5. После загрузки открой Actions → Build Superman.
6. Готовый `Superman.asi` появится в Artifacts.

Проект не использует ScriptHookVDotNet и NIBSHDotNet.
