Put the official ScriptHookV SDK header here:
include/ScriptHookV/main.h

The SDK itself is not redistributed by this project.
