@echo off
setlocal
if not exist build mkdir build

cl /LD /EHsc /std:c++17 ^
  /Iinclude ^
  src\main.cpp src\Superman.cpp src\Flight.cpp src\Abilities.cpp ^
  /link /OUT:build\Superman.asi

if errorlevel 1 exit /b 1
echo Built build\Superman.asi
