# Superman GTA V Legacy 3889 — Realistic ASI

Standalone ScriptHookV ASI project for GTA V Legacy 3889.

## Features
- Smooth physics-based flight with acceleration, drag and braking
- Air steering and banking
- Boost flight with a speed cap
- Super speed on the ground
- Super strength / heavy melee
- Heat vision mode
- Freeze-breath mode
- Reduced fall damage / controlled landing
- Superman toggle and configurable keys
- No ScriptHookVDotNet
- No NIBSHDotNet
- No external trainer dependency

## Default keys
- F3 — Superman ON/OFF
- F4 — Flight ON/OFF
- Left Shift — boost while flying / super speed on ground
- E — heat vision
- Q — freeze breath
- Space — fly upward
- Left Ctrl — fly downward
- W/S — forward/back
- A/D — turn
- Mouse look controls the facing direction through the normal player heading

## Build
The repository expects the ScriptHookV SDK in:
`include/ScriptHookV/main.h`

The GitHub Actions workflow builds:
`Superman.asi`

Place the resulting `Superman.asi` beside `ScriptHookV.dll` and `dinput8.dll` in GTA V.

This project intentionally does not use ScriptHookVDotNet or NIBSHDotNet.


## Правильная структура

```text
Superman-GTA5-Mod-3889/
├── .github/workflows/build.yml
├── config/Superman.ini
├── include/ScriptHookV/main.h   <-- добавить из официального SDK
└── src/
    ├── main.cpp
    ├── Superman.cpp
    ├── Superman.h
    ├── Flight.cpp
    ├── Flight.h
    ├── Abilities.cpp
    ├── Abilities.h
    └── Native.h
```
